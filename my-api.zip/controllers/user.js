import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User } from "../models/user.js";
import { uploadFileToS3, getImageUrl } from "../utils/file_upload.js";
import { Order } from "../models/orders.js";


export const getAllUsers = async (req, res) => {
  let updatedUsers = [];
  try {
    const users = await User.findAll({
      attributes: { exclude: ["password"] },
    });
    for(let user of users) {
      let new_user = user.toJSON();
      if (user.profilePicture) {
        new_user.profilePicture = await getImageUrl(user.profilePicture);
        updatedUsers.push(new_user);
      } else {
        updatedUsers.push(new_user);
      }
    }
    res.status(200).json(updatedUsers);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

// create a new user and hash the password before saving to the database
export const registerUser = async (req, res) => {
  try {
    const { email, password, role } = req.body;
    const profilePicture = req.file ? await uploadFileToS3(req.file) : null;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await User.create({
      email,
      password: hashedPassword,
      role,
      profilePicture: profilePicture,
    });
    res.status(201).json({ id: newUser.id, email: newUser.email, role: newUser.role, profilePicture: newUser.profilePicture });
  } catch (error) {
    console.log(error)
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};


// login a user and return a JWT token
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

// get a user by id
export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    let new_user = user.toJSON();
    if (user.profilePicture) {
      new_user.profilePicture = await getImageUrl(user.profilePicture);
      return res.status(200).json(new_user);
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

// update a user's profile picture
export const updateProfilePicture = async (req, res) => {
  try {
    const { id } = req.params;
    // ensure that authenticated user can only update their own profile picture
    if (req.user.id !== id) {
      return res.status(403).json({ error: "Forbidden: You can only update your own profile picture" });
    }
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const profilePicture = req.file ? await uploadFileToS3(req.file) : null;
    await user.update({ profilePicture });
    let updated_user = user.toJSON();
    if (user.profilePicture) {
      updated_user.profilePicture = await getImageUrl(user.profilePicture);
      return res.status(200).json(updated_user);
    }
    res.status(200).json({
      message: "Profile picture updated successfully",
      attributes: {
        id: user.id,
        email: user.email,
        role: user.role,
        profilePicture: user.profilePicture,
      },
    });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

// promote a user to admin role
export const promoteToAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    await user.update({ role: "admin" });
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

// soft delete a user by setting the deletedAt field to the current date and time and soft delete all orders associated with the user as well
export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    // make sure that authenticated user can only delete their own account;
    if (req.user.id !== user.id) {
      return res.status(403).json({ error: "Forbidden: You can only delete your own account" });
    }
    await user.update({ deletedAt: new Date() });
    await Order.update({ deletedAt: new Date() }, { where: { userId: id } });
    res.status(200).json({ message: "User and associated orders soft deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error", name: error.name });
  }
};

